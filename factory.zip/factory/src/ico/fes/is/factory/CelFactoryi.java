/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.is.factory;

/**
 *
 * @author silve
 */
public interface CelFactoryi {

    public static int HUAWEI_30P_LITE = 0;
    public static int HUAWEI_30P_PRO = 1;
    public static int IPHONE_X = 2;
    public static int IPHONE_X_PRO_MAX = 3;
    public static int SAMGUNG_GALAXY_A50= 4;

}
