/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.is.factory;

import javax.crypto.spec.PSource.PSpecified;

import sun.net.www.content.text.plain;

/**
 *
 * @author silve
 */
public interface Snack {

    public static final int PIZZA_HAW = 1;
    public static final int PIZZA_MARG = 2;
    public static final int PIZZA_CARNE =3;
    public static final int HAMBURGUESA_HAW = 4;
    public static final int HAMBURGUESA_DOBLE_CON_QUESO = 5;
    public static final int PIZZA_PEPERONI = 6;
    public static final int HAMBURGUESA_BBQ =7;
    public static final int HAMBURGUESA_DE_POLLO =8;
    public static final int TORTA_BASICA = 9;
    public static final int TORTA_CUBANA = 10;
    public static final int TORTA_RUSA = 11;
    public static final int TORTA_MILANESA =12;



        
    }
    


